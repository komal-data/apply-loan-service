package com.apply.loan.exceptions;

public class ApplicationAlreadyExistException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;

	public ApplicationAlreadyExistException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
