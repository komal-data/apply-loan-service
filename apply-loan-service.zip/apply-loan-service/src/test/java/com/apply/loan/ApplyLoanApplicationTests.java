package com.apply.loan;

import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;

@ExtendWith(org.mockito.junit.jupiter.MockitoExtension.class)
class ApplyLoanApplicationTests {

	@Test
	void contextLoads() {
		assertTrue(true);
	}

}
