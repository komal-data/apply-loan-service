package com.apply.loan.dto;

import lombok.NoArgsConstructor;

@NoArgsConstructor

public class JWTResponse {

	private String token;

}
